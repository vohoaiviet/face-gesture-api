% DTW & CDTW example
% Sinusoidal signals temporal alignment

%fs=125;
%f1=1; A1=1;
%f2=5; A2=0.8;
%t1=0:1/fs:1/(2*f1);
%t2=0:1/fs:2/(2*f2);
%n1=(A1/10)*rand(size(t1));
%n2=(A2/8)*rand(size(t2));
%s1=A1*sin(2*pi*f1*t1)+n1; % 1st sinusoid with noise addition
%s2=A2*sin(2*pi*f2*t2)+n2; % 2nd sinusoid with noise addition

t1 = [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17];
t2 = [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18];
seq1 = [90. 90. 90. 90. 90. 90. 90. 270. 270. 270. 270. 270. 270. 270. 270. 225. 135. 180.];
seq2 = [90. 90. 90. 90. 90. 225. 270. 270. 270. 270. 270. 270. 270. 270. 270. 270. 225. 135. 90.];

figure; hold on;
plot(t1, seq1,'b');
plot(t2, seq2,'r');
grid;
xlabel('time (s)');
ylabel('amplitude (mV)');
title('Original disaligned waves');

pflag=1;

[dtw_Dist,D,dtw_k,w,s1w,s2w]=dtw(seq1,seq2,pflag);
dtw_Dist, dtw_k

[cdtw_Dist,D,cdtw_k,w,s1w,s2w]=cdtw(seq1,seq2,pflag);
cdtw_Dist, cdtw_k
